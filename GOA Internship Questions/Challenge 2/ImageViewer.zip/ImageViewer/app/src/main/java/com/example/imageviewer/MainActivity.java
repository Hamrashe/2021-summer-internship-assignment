package com.example.imageviewer;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;

import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;

public class MainActivity extends AppCompatActivity {
    ListView mListView;

    //Images array
    int[] imagesArray = {R.drawable.image1,
            R.drawable.image2,
            R.drawable.image3};

    //Image names
    String[] imageNames = { "purple", "orangutan", "space" };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mListView = (ListView)findViewById(R.id.listview);
        Adapter adapter = new Adapter(MainActivity.this, imageNames, imagesArray );
        mListView.setAdapter(adapter);
        mListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                Intent mIntent = new Intent(MainActivity.this, DetailActivity.class);
                mIntent.putExtra("imagesArray", imagesArray[i]);
                startActivity(mIntent);

            }
        });


    }
}